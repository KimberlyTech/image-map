window.ImageMapPro = {}
window.ImageMapPro.instances = []