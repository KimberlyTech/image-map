export default {
  setExampleMutation: (state, payload) => {
  }
}