import { imageMapDefaults } from 'Client/scripts/defaults'

let state = imageMapDefaults

export default state