<script>
  export let title
</script>

<div class="p-1 my-2 text-xs font-bold">
  <div class="pb-2">
    <div class="bg-theme-200 dark:bg-theme-700 h-px" />
  </div>
  {title}
</div>
