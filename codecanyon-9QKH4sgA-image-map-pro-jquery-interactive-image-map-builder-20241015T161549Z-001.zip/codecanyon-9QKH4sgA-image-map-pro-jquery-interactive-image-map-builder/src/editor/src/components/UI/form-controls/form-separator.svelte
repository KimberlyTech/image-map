<script>
</script>

<div class="py-2 -ml-1 -mr-1">
  <div class="bg-theme-200 dark:bg-theme-700 h-px" />
</div>
