<div class="w-full my-1 px-2">
  <div class="h-px bg-theme-200 dark:bg-theme-700" />
</div>
