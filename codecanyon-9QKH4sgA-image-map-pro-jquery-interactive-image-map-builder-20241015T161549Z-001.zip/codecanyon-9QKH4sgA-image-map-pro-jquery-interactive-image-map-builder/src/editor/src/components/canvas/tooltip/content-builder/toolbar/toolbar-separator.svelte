<div class="bg-black dark:bg-white bg-opacity-20 dark:bg-opacity-20 w-px h-4 mx-2" />
