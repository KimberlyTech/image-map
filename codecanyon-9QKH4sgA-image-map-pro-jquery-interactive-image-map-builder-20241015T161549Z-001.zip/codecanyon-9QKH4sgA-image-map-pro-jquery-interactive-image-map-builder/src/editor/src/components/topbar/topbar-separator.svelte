<div class="w-px h-10 mx-2 bg-theme-500 opacity-25" />
