import '../assets/index.css'
import App from './App'

var app = new App({
  target: document.querySelector('#image-map-pro-editor')
})

export default app